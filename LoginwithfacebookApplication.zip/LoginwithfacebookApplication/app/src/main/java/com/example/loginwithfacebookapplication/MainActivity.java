package com.example.loginwithfacebookapplication;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    CallbackManager callbackManager;
    private static final String EMAIL = "email";
    LoginButton loginButton;
    TextView textViewemail,textViewname;
    CircleImageView circleImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        circleImageView = findViewById(R.id.circleImageView2);
        loginButton = findViewById(R.id.login_button);
        textViewemail = findViewById(R.id.textView4);
        textViewname = findViewById(R.id.textView5);
        printhashkey();
        chechuserlogin();
        AccessTokenTracker accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken currentAccessToken) {
                if (currentAccessToken==null)
                {
                    textViewemail.setText("");
                    textViewname.setText("");
                    circleImageView.setImageResource(R.drawable.com_facebook_button_icon);
                    Toast.makeText(MainActivity.this,"useer is logged out ",Toast.LENGTH_SHORT).show();

                }
                else {
                    LoadProfiledata(currentAccessToken);
                }

            }
        };
        loginButton.setReadPermissions(Arrays.asList("email","public_profile"));
        callbackManager = CallbackManager.Factory.create();


        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
          @Override
          public void onSuccess(LoginResult loginResult) {
              Toast.makeText(MainActivity.this,"sucesss",Toast.LENGTH_SHORT).show();

          }

          @Override
          public void onCancel() {
              Toast.makeText(MainActivity.this,"cancelll",Toast.LENGTH_SHORT).show();

          }

          @Override
          public void onError(FacebookException error) {
              Toast.makeText(MainActivity.this,"error",Toast.LENGTH_SHORT).show();

          }
      });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void LoadProfiledata(AccessToken accessToken)
    {
        GraphRequest graphRequest = new GraphRequest().newMeRequest(accessToken, new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {
                try {
                    String firstname = object.getString("first_name");
                    String lastname = object.getString("last_name");
                    String email = object.getString("email");
                    String serid = object.getString("id");
                    String Image_url = "https://graph.facebook.com/"+serid+"/picture?type=normal";
                    textViewemail.setText(email);
                    textViewname.setText(firstname +"  * " +lastname);
                    RequestOptions requestOptions = new RequestOptions();
                    requestOptions.dontAnimate();
                    Glide.with(MainActivity.this).load(Image_url).into(circleImageView);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        Bundle parameters = new Bundle();
        parameters.putString("fields","first_name,last_name,email,id");
        graphRequest.setParameters(parameters);
        graphRequest.executeAsync();
    }

    public void printhashkey(){

        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "com.example.loginwithfacebookapplication",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHashFacebookloginn:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }

    }

    public void chechuserlogin()
    {
        if (AccessToken.getCurrentAccessToken()!=null)
        {
            LoadProfiledata(AccessToken.getCurrentAccessToken());
        }
    }
}
